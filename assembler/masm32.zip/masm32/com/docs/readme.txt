Having no idea what one may come here seeking, I make no statement as to
what order you should review this material.

However, those who would wish a path to follow may find this order acceptable:

    Accessing COM Objects from Assembly.doc
    
    Standard for COM in MASM32.doc
    
    Adapting Quick Editor for COM.doc
    
    Creating a COM object in ASM.doc
    
    MyCom2 and the CoLib.doc
    
    Inside CoLib.doc
    
    UsingCoLib to Build a Visual Control.doc
