I've added a few very new goodies here.

bstrLib adds several VB string-like functions for
handeling the BSTR type.

IEnumVariant is the basic automation enumeration
interface. It's what's behind a scripter when running
a "For each Thing in Things" iteration.

Neither of these new additions has been tested in
a real application yet. They repersent the cutting 
edge of where I am