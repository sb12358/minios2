  -------------------------------------------------------
   readme.txt for colib, the Component Object Library

    Release 1.0 
  -------------------------------------------------------
  Copyright (c) 9/28/00  Ernest Murphy
  For educational use only. 
  Any commercial re-use only by written license
 
  -------------------------------------------------------


  These are the assembly language files for the CoLib components.
They may be built by running the make.bat file.

Revision history
	2/25/01 version 1.1 beta test. split DllGetClasObject defs
		so non-dll objs may be created without pulling in
		dll code. 
	1/8/01	includelib oleaut32.lib added to Invoke.asm	



