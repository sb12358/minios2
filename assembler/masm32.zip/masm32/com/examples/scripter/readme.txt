Place actiscp.inc and msscript.inc into your /masm32/COM/include directory 
before attempting to build ScripTxt.


em