Hello,

 This example was written by Thomas Bleeker.

 This example is to show how to inherit from one class and provide a new class
 with simular properties, but extended with some extra properties as well.

 CSmiles is written to inherit from CSprite.

 Thus, CSmiles is pretty well the same class as CSprite, except the CSmiles 
 class also provides an extra feature:  to display foots steps where each 
 instance of a CSmiles object has gone. (Remember since it inherits from
 CSprite, it will act like CSprite and have move methods etc. etc.)

 This is an exellent example of OOP's usage, as this example not only shows
 inheritance, but it also shows the need for OVERIDING certian methods and 
 allow for polymophism to take place (the Draw method is polymorphic between
 the two classes).  As well as polymorophism, the draw method also shows 
 proper usage of the SUPER macro to first call the SUPER.draw method and 
 re-use as much code as possible before extending the draw method to do more
 "work".  The super macro is also put to use in both the CONSTRUCTOR and 
 DESTRUCTOR of the CSmiley class.  This is a MUST for proper inheritance.


List of changes:

  CSmiley 		(new class inherits CSprite)
  codeparts 		Initializaton and CleanUp uses CSmilely objects now
  drawproc		Modified to preserve background, and call Smiley Objects
  window		Modified to have an extra DC for footprints.
  rsrc.rc		Modified to include one more footprint bitmap
  Smiles.inc 		Modified to include CSmiley.asm


 

Compiling:

 In the interest of space in Hutch's package, only the new or modified code it within this directory.  To compile the example of inheritance do the following:

  1) Copy all the previous example code for CSprite into a new project directory.

  2) Copy all the files from this directory OVERTOP of the files you just copied.
     (Since these are the new or modified files).

  3) Copy the OBJECTS.INC file into the project directory.

  4) Compile using Hutch's "builda.bat".

Sorry for any inconvienence, but to have two isollated code examples would have alot of redundant code and graphics compiled into this package.

Nan.