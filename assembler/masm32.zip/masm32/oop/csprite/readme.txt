Hello,

 This example was written by Thomas Bleeker.

 Its purpose is to provide a basic example of how one can use our OOP model
 to create and manage a large number of sprite objects and display them using
 windows' GUI.

 To build, first copy the "OBJECTS.INC" into this directory (removed from each
 example to conserve space).

 This example will compile completely with HUTCH's batch file 'builda.bat'

 Nan.